# À table ! — Recettes & courses

Petite application web progressive (PWA) de cuisine, **100 % locale**, en HTML/CSS/JavaScript vanilla. Aucune bibliothèque, police ou API externe n’est utilisée. Recettes et liste de courses sont stockées dans le `localStorage` du navigateur : elles restent sur cet appareil et ne sont pas envoyées à un serveur. Le service worker met en cache l’interface pour un usage hors ligne après le premier chargement.

## Fonctionnalités

- Un menu d’accueil obligatoire propose trois chemins : composer les courses depuis les recettes, ouvrir la liste ou parcourir les recettes. Le bouton maison rouvre ce menu ; il n’est pas refermable sans choisir une destination.
- Carnet de recettes : créer, afficher, rechercher, modifier et supprimer une recette. Chaque fiche comprend nom, portions, ingrédients (quantité et unité), étapes et notes.
- Composition de courses : sélection de plusieurs recettes et ajustement du nombre de portions. Les quantités numériques sont recalculées proportionnellement ; les ingrédients de même nom et unité sont regroupés. Les quantités numériques sont additionnées, sinon conservées sous forme de libellés « quantité + quantité ».
- Liste de courses : ajout libre, coche/décoche, suppression d’un article, effacement des articles cochés ou de toute la liste.
- Export et import JSON du carnet ; les noms de recettes déjà présents sont ignorés à l’import.
- Interface mobile avec grandes zones de commande, safe areas iPhone, mode sombre système, installation sur l’écran d’accueil.

## Installer sur iPhone

### Option simple : GitHub Pages

1. Créez un dépôt GitHub et ajoutez les fichiers du dossier `courses-app` à la racine (ou publiez ce dossier comme racine du site).
2. Dans **Settings → Pages**, choisissez la branche et le dossier à publier, puis enregistrez. GitHub fournit une adresse HTTPS.
3. Sur l’iPhone, ouvrez cette adresse dans **Safari** (l’installation PWA ne se fait pas depuis un navigateur intégré à une autre app).
4. Touchez **Partager** → **Sur l’écran d’accueil** → **Ajouter**.
5. Ouvrez l’icône créée. Chargez l’application une première fois en ligne : les ressources sont alors mises en cache et les visites suivantes fonctionnent hors ligne.

### Option simple : Netlify Drop

1. Sur un ordinateur, ouvrez [Netlify Drop](https://app.netlify.com/drop) et déposez le dossier `courses-app` (ou son contenu).
2. Une fois le déploiement terminé, ouvrez l’adresse HTTPS donnée par Netlify dans Safari sur l’iPhone.
3. Choisissez **Partager → Sur l’écran d’accueil → Ajouter**. Ouvrez l’application au moins une fois en ligne pour amorcer le cache hors ligne.

### Développement sur le réseau local

Dans un terminal, depuis le dossier contenant l’application :

```sh
cd courses-app
python3 -m http.server 8000
```

Repérez l’adresse IP locale de l’ordinateur (par exemple `192.168.1.20`), puis ouvrez `http://192.168.1.20:8000` sur l’iPhone, connecté au même Wi-Fi. Pour le développement, le service worker est généralement autorisé sur `localhost`, mais pas sur une adresse réseau HTTP ordinaire. Cette méthode permet de vérifier l’interface ; **le mode hors ligne installable exige HTTPS** (ou localhost sur l’appareil qui sert le site). Pour l’installation iPhone, préférez GitHub Pages ou Netlify.

## Utilisation et sauvegarde

Les données sont séparées par navigateur et appareil. Videz régulièrement vos recettes seulement après avoir exporté une sauvegarde JSON depuis **Voir mes recettes → Exporter mes recettes**. Utilisez **Importer une sauvegarde** pour la restaurer ; les recettes portant un nom déjà présent sont ignorées. Effacer les données Safari peut également effacer les données locales.

## Modifier le code

- `index.html` : structure, textes principaux, manifeste, métadonnées Apple et point d’entrée JS.
- `style.css` : couleurs via les variables en tête de fichier, composants, responsive et thème sombre.
- `app.js` : application découpée en fonctions de rendu (`renderRecipes`, `renderShopping`, `renderEditor`, etc.), persistance (`saveRecipes`, `saveShopping`), import/export et actions déléguées. Les clés de stockage sont versionnées en tête du fichier.
- `manifest.webmanifest` : nom, couleurs et paramètres d’installation ; les icônes associées sont `icon-180.png`, `icon-192.png` et `icon-512.png`.
- `sw.js` : cache initial des ressources essentielles. Si vous ajoutez un fichier d’interface, ajoutez-le à `APP_ASSETS` et incrémentez `CACHE_NAME` pour invalider l’ancien cache.

Après modification, rechargez le site. En cas d’ancien affichage, fermez/réouvrez l’application ou supprimez ses données de site pour vider le cache du service worker. Une recherche globale des chaînes `data-action` permet de relier les boutons au gestionnaire d’événements de `app.js`.

## Vérification locale

Depuis ce dossier :

```sh
node --check app.js
node --check sw.js
```

Pour un test rapide des fonctions de regroupement des quantités :

```sh
node - <<'JS'
const { sumQuantities } = require('./app.js');
if (sumQuantities('2', '3') !== '5') throw new Error('Addition numérique incorrecte');
if (sumQuantities('une pincée', 'une pincée') !== 'une pincée + une pincée') throw new Error('Libellé incorrect');
console.log('Tests de quantités OK');
JS
```
